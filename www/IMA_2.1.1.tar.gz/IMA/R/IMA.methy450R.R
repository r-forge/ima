IMA.methy450R <-
function(fileName, columnGrepPattern=list(beta=".AVG_Beta",detectp=".Detection.Pval"),groupfile){
        cat("For a desktop with 2GB memory and 7200RPM hard disk,\nthe estimated time of this process is 1-2 mins for a dataeset with 10 samples and 6-7 mins for a dataset with 200 samples\n......Extracting the beta value matrix.....\n")
        temp = readLines(fileName, n=20)
	nskip = grep(columnGrepPattern$beta,temp,ignore.case=TRUE)-1
	titleLine <- temp[nskip + 1]
	allcolname = unlist(strsplit(titleLine,"\t"))
	betacol = grep(columnGrepPattern$beta,allcolname)
	pvalcol = grep(columnGrepPattern$detectp,allcolname)
	annotcol = grep("ILMNID",allcolname):(length(allcolname))
	####define the colClasses ###Here "colClasses" option is a vector and NULL must be quoted
	colClasses=rep("NULL",length(allcolname))
	colClasses[1] = "character"
	colClasses[betacol] = "numeric"
	betamatrix <- read.delim(file=fileName, header=TRUE, sep="\t", skip=nskip, colClasses=colClasses, na.string=c("NA",""),check.names = FALSE,row.names=1)[,1:length(betacol)]
	# user  system elapsed for about 200 samples
	#382.600   2.930 390.454 
	cat("......Extracting the pvalue matrix......\n")
        colClasses2 = rep("NULL",length(allcolname))
	colClasses2[1] = "character"
	colClasses2[pvalcol] = "numeric"
	detect_p <- read.delim(file=fileName, header=TRUE, sep="\t", skip=nskip, colClasses=colClasses2,na.string=c("NA",""),check.names = FALSE,row.names=1)[,1:length(pvalcol)]
	# user  system elapsed for about 200 samples
	#390.920   1.370 393.877 
	cat("......Extracting the annotation matrix......\n")
	colClasses3 = rep("NULL",length(allcolname))
	colClasses3[1] = "character"
	colClasses3[annotcol] = "character"
	annotation <- read.delim(file=fileName, header=TRUE, sep="\t", skip=nskip, colClasses=colClasses3, strip.white=TRUE,na.string=c("NA",""),check.names = FALSE,row.names=1)[,1:length(annotcol)]
	# user  system elapsed 
	#429.220   1.140 431.932 
        sname = sub(columnGrepPattern$beta,"",colnames(betamatrix))
        colnames(betamatrix) = colnames(detect_p) = sname
        ####match the phenotype data with the methylation data
        cat("Read phenotype data...\n");
        group = data.frame(read.delim(groupfile,sep="\t",header = TRUE))
        #group[,1] = gsub(" ",".",gsub("-",".",group[,1]))      
        cat("Matching the orders of samples between phenotype data and beta value matrix. \n");
        index = match(group[,1],colnames(betamatrix))
        if(sum(is.na(index))>0){
                cat("ERROR:\nBelow samples couldn't be found in beta matrix:\n",group[is.na(index),1],"\n.")
        }
        cat("Total CpG sites without any filtering are:",nrow(betamatrix),"\nTotal samples are:",ncol(betamatrix),"\n"); 
        betamatrix=betamatrix[,index]
        detect_p = detect_p[,index]
        rownames(group) = sname[index] 
        setClass("exprmethy450", representation(bmatrix = "matrix",annot = "matrix",detectP = "matrix",groupinfo = "data.frame"),where = topenv(parent.frame()))
        x.methy450 = new("exprmethy450",bmatrix=as.matrix(betamatrix),annot=as.matrix(annotation),detectP=as.matrix(detect_p),groupinfo = group)
        
        cat("....Starting Quality Control...\n")
        require(bioDist)
        eset = na.omit(betamatrix)
        samples = paste(group[,1],group[,2],sep="_")
        hc1<-hclust(cor.dist(t(eset)), method="average")
        pdf("./QC.pdf",width=24)
        plot(hc1,samples, xlab="Sample", main="Clustering samples by all the CpG loci ", lwd=2, font.axis=2, font.lab=2)
        boxplot(betamatrix,ylab = "beta Value")
        avgPval = apply(detect_p,2,function(x){sum(x>=1e-5)*100/length(x)})
        barplot(avgPval, ylab = "% of detect pvalue >1e-5")
        dev.off()
        cat("An exprmethy450 class are created and the slotNames are:\n",slotNames(x.methy450),"\n");
        cat("Basic Quality Control information can be found in QC.pdf file\n");            
        return(x.methy450)
}


