annotfunc <-
function(listtoannot,fullannot,filteredannot,fullIndexannot,filteredIndexannot,category = c("site","region")){
        if(category == "site"){
                out = fullannot[match(listtoannot,fullannot[,1]),]
        }else{
                index1 = match(listtoannot,names(fullIndexannot$SID))
                index2 = match(listtoannot,names(filteredIndexannot$SID))
                tempfunc <- function(index,annot,indexannot){
                        temp = indexannot$PID[[index]]
                        temp = rbind(annot[temp,])
                        return(unlist(lapply(apply(temp,2,unique),paste,collapse="/")))
                }
                test <- sapply(index1,function(x)tempfunc(x,fullannot,fullIndexannot))

                a = lapply(fullIndexannot$SID[index1],length)
                b = lapply(filteredIndexannot$SID[index2],length)
                out = cbind(unlist(a),unlist(b),t(test))
                colnames(out)[1:3] = c("# of Ori_Designed sites","# of sites After Filtering","Designed Probes")
        }
        return(out)
}
